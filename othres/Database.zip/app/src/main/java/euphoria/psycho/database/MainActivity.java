package euphoria.psycho.database;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.os.Environment;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestPermissions(new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.READ_EXTERNAL_STORAGE,
        }, 99);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Databases databases = new Databases(this, new File(Environment.getExternalStorageDirectory(), "1.db").getAbsolutePath());
        databases.refreshSearch();
    }

    public class Model {
        private String Title;
        private String Content;
        private int DrugId;

    }

    public class Databases extends SQLiteOpenHelper {

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {

            // sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS \"SqliteModel\" ( \"Id\" integer primary key autoincrement not null , \"Title\" varchar , \"Tag\" varchar , \"Content\" varchar , \"UpdateTime\" bigint , \"CreateTime\" bigint )");

            sqLiteDatabase.execSQL("CREATE VIRTUAL TABLE IF NOT EXISTS _search USING fts4(title,content, drug_id, drug_type, tokenize=icu zh_CN)");

            sqLiteDatabase.setLocale(Locale.CHINA);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        }

        public Databases(Context context, String name) {
            super(context, name, null, 1);
        }


        public void refreshSearch() {
            String columns = "id,name,alias,source,harvest_preparation,commercial_specification,properties,channels_tropism,functions,indications,dosage,cautions,commentary,chemical_compositions,pharmacological_effects,pharmacodynamics,clinical_reports,toxicity,`references`";

            Cursor cursor = getReadableDatabase().rawQuery("select " + columns + " from t_chinese_medicine", null);

            List<Model> models = new ArrayList<>();
            while (cursor.moveToNext()) {
                Model model = new Model();
                model.DrugId=cursor.getInt(0);

                model.Title = cursor.getString(1);
                model.Content = cursor.getString(2) + "\n\n" + cursor.getString(3) + "\n\n" + cursor.getString(4) + "\n\n" + cursor.getString(5) + "\n\n" + cursor.getString(6) + "\n\n" + cursor.getString(7) + "\n\n" + cursor.getString(8) + "\n\n" + cursor.getString(9) + "\n\n" + cursor.getString(10) + "\n\n" + cursor.getString(11) + "\n\n" + cursor.getString(12) + "\n\n" + cursor.getString(13) + "\n\n" + cursor.getString(14) + "\n\n" + cursor.getString(15) + "\n\n" + cursor.getString(16);
                models.add(model);
            }

            cursor.close();
            SQLiteDatabase sqLiteDatabase = getWritableDatabase();
            for (Model model : models) {

                ContentValues contentValues = new ContentValues();
                contentValues.put("drug_id", model.DrugId);
                contentValues.put("drug_type", 4);
                contentValues.put("title", model.Title);
                contentValues.put("content", model.Content);
                sqLiteDatabase.insert("_search", null, contentValues);
            }


        }


    }
}
