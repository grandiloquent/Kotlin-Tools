package psycho.euphoria.common.download

class NetworkResponse(
        var notModified:Boolean
) {

}