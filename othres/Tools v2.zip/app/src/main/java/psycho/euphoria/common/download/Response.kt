package psycho.euphoria.common.download

class Response {

}