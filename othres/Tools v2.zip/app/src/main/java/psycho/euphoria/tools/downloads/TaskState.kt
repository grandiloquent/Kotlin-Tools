package psycho.euphoria.tools.downloads


data class TaskState(var id: Long, var speed: Long,
                     var current: Long, var total: Long)

