package psycho.euphoria.tools.ui

import android.content.Context
import android.graphics.Bitmap
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import com.google.android.exoplayer2.ExoPlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.util.ErrorMessageProvider
import sun.audio.AudioPlayer.player




class PlayerView : FrameLayout {

    var errorMessageProvider: ErrorMessageProvider<in ExoPlaybackException>? = null
        set(value) {
            if (field != value) {
                field = value
                updateErrorMessage()
            }

        }

    var defaultArtwork: Bitmap? = null
    var useArtwork = false
    var showBuffering = false
    var keepContentOnPlayerReset = false
    var customErrorMessage: CharSequence? = null
    var controllerShowTimeoutMs = 0L
    var controllerHideOnTouch = false
    var controllerAutoShow = false
    var controllerHideOnAds = false
    var surfaceView: View? = null
    var overFrameLayout: FrameLayout? = null
    var subtitleView: SubtitleView? = null
    var useController = false
    var player: Player? = null
    lateinit var mController: PlayerControlView

    private var mErrorMessageView: View? = null


    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet, defStyle: Int) : super(context, attrs, defStyle)

//
//    override fun onTouchEvent(event: MotionEvent): Boolean {
//
//        if (!useController || player == null || event.actionMasked != MotionEvent.ACTION_DOWN) {
//            return false
//        }
//        if (!mController.isVisible()) {
//            maybeShowController(true)
//        } else if (controllerHideOnTouch) {
//            mController.hide()
//        }
//        return true
//    }
//
//    private fun maybeShowController(isForced: Boolean) {
//        if (isPlayingAd() && controllerHideOnAds) return
//        if (useController) {
//            val wasShowingIndefinitely = mController.isVisible() &&  mController.getShowTimeoutMs() <= 0
//            val shouldShowIndefinitely = shouldShowControllerIndefinitely()
//            if (isForced || wasShowingIndefinitely || shouldShowIndefinitely) {
//                showController(shouldShowIndefinitely)
//            }
//        }
//    }
//
//    fun showController() {
//        showController(shouldShowControllerIndefinitely())
//    }
//
//    private fun showController(showIndefinitely: Boolean) {
//        if (!useController) {
//            return
//        }
//        controller.setShowTimeoutMs(if (showIndefinitely) 0 else controllerShowTimeoutMs)
//        controller.show()
//    }
//    private fun shouldShowControllerIndefinitely(): Boolean {
//        if (player == null) {
//            return true
//        }
//        val playbackState = player.getPlaybackState()
//        return controllerAutoShow && (playbackState == Player.STATE_IDLE
//                || playbackState == Player.STATE_ENDED
//                || !player.getPlayWhenReady())
//    }
//    private fun isPlayingAd(): Boolean {
//        return player?.isPlayingAd == true && player?.playWhenReady == true
//    }
//
//    private fun updateErrorMessage() {
//        mErrorMessageView?.let {
//
//        }
//    }

    companion object {
        const val SURFACE_TYPE_NONE = 0
        const val SURFACE_TYPE_SURFACE_VIEW = 1
        const val SURFACE_TYPE_TEXTURE_VIEW = 2
    }
}