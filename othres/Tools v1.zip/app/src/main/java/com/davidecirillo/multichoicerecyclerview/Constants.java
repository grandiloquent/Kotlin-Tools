package com.davidecirillo.multichoicerecyclerview;

public class Constants {

    /**
     * Used for res-variables as a default value.
     * This way, we can detect if a value was set or not.
     */
    public static final int INVALID_RES = -1;
}
